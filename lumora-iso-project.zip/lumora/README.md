# Lumora Linux (base Debian 13 + KDE Plasma)
## Gerar a ISO (não mexe no Windows)
Opção A, pela nuvem (dá até pelo celular): suba esta pasta num repositório GitHub > Actions > build-iso > Run workflow. Baixe a ISO e o .sha256 em "Artifacts".
Opção B: numa VM Debian 13: `sudo ./build.sh` (precisa ~15 GB livres).
## Testar no Windows (VM)
1. Instale o VirtualBox. 2. Nova VM: Linux/Debian 64-bit, 4 GB RAM, 2+ CPUs, 40 GB disco VIRTUAL, marque "Enable EFI". 3. Em Armazenamento, aponte o drive óptico para a ISO. 4. Inicie e escolha o modo live.
Confira o checksum: PowerShell `Get-FileHash .\lumora-1.0-amd64.iso -Algorithm SHA256`.
## Instalar no futuro
ATENÇÃO: instalar no PC real pode APAGAR dados do disco escolhido. Faça backup. Para manter o Windows, reduza uma partição pelo Windows e use "instalar ao lado" no Calamares; ou use um SSD separado. Nunca escolha "Apagar disco" sem ter certeza do disco.
## Limitações
Roblox: o cliente oficial não roda em Linux; Sober é não oficial e pode quebrar. Jogos com anti-cheat de kernel costumam não funcionar. PowerPoint real não existe no Linux: use ONLYOFFICE, LibreOffice ou a versão web.
